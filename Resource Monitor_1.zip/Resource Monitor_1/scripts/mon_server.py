import socket
import json
import matplotlib.pyplot as plt
from drawnow import *
import numpy as np

cpu_usage = []
mem_usage = []
net_usage = []
client_ip =''
window_size =20

def plot_me():  
    plt.plot(list(np.arange(len(cpu_usage))),
             cpu_usage,
             'r:o',
             label='CPU Usage')
    plt.plot(list(np.arange(len(mem_usage))),
             mem_usage,
             'g:o',
             label='Mem Usage')
    plt.plot(list(np.arange(len(net_usage))),
             net_usage,
             'b:o',
             label='Net Usage')
    
    plt.grid(True)
    plt.legend()
    plt.yscale('log')
    plt.suptitle(f'Monitoring {client_ip}')
    
skt = socket.socket() #creates a soket obj
buf_size = 1024 #input buffer size
port = int(input('Enter local port : '))

skt.bind(('',port)) #opens port on the soket
print(f'Port number {port} is live...')

skt.listen() #wait for a connection request
print('Listening...')

client, addr = skt.accept() #accept client req
print(f'Connection from {addr} is received...')

while(True):
    msg = client.recv(buf_size) #recv client data
    if not msg:
        print('No Data!')
    else:
        data = json.loads(msg)  #Deserialization
        
        client_ip = addr[0]
        # update time series 
        if len(cpu_usage) > window_size:
            cpu_usage.pop(0)
            mem_usage.pop(0)
            net_usage.pop(0)
            
        cpu_usage.append(data['cpu']['per'])
        mem_usage.append(data['mem']['per'])
        net_usage.append(data['net']['pkt_rate'])
        
        print(f'{addr} sends {data}')
        drawnow(plot_me)