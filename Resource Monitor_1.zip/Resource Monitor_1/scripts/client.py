import socket
import json
import time

skt = socket.socket()

srv_ip = input(r'Enter Server IP: ') #must be a raw input
srv_port = int(input('Enter Server Port: '))

skt.connect((srv_ip, srv_port))  #send a connection request
while (True):
    data = {'name':'hello', 'value':time.time()}
    msg = str.encode(json.dumps(data)) # encapsulate
    skt.send(msg)
    time.sleep(1)
