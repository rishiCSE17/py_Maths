import socket
import json
import time
import psutil as ps

def get_profile():
    import time
    ret = {}  # dictionary to return 
    
    cpu = {'count':ps.cpu_count(), #no of CPU cores
           'per':ps.cpu_percent()} #% of CPU usage 
    mem = {'total':round(ps.virtual_memory()[0]/1024**3,2), #Memory in GB
           'per':ps.virtual_memory()[2]}                    #% of mem use 
    
    t1 = ps.net_io_counters()[2] + ps.net_io_counters()[3] # no. of pkt sent+rcv
    time.sleep(1)                                          # wait 1 sec
    t2 = ps.net_io_counters()[2] + ps.net_io_counters()[3] # no. of pkt sent+rcv
    net = {'pkt_rate':(t2-t1)}                             # packets /sec
    
    ret={'cpu' : cpu , 'mem' : mem, 'net' : net}
    
    return ret    

skt = socket.socket()

srv_ip = input(r'Enter Server IP: ') #must be a raw input
srv_port = int(input('Enter Server Port: '))

skt.connect((srv_ip, srv_port))  #send a connection request
while (True):
    data = get_profile()
    msg = str.encode(json.dumps(data)) # encapsulate
    skt.send(msg)
    time.sleep(1)
