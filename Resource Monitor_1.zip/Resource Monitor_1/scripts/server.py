import socket
import json

skt = socket.socket() #creates a soket obj
buf_size = 1024 #input buffer size
port = int(input('Enter local port : '))

skt.bind(('',port)) #opens port on the soket
print(f'Port number {port} is live...')

skt.listen() #wait for a connection request
print('Listening...')

client, addr = skt.accept() #accept client req
print(f'Connection from {addr} is received...')

while(True):
    msg = client.recv(buf_size) #recv client data
    if not msg:
        print('No Data!')
    else:
        data = json.loads(msg)  #decapsulate 
        print(f'{addr} sends {data}')
    

